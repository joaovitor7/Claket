import sys
if sys.version_info[0] < 3:
    import got
else:
    import got3 as got

def main():

	def printTweet(descr, t):
		print(descr)
		print("Username: %s" % t.username)
		print("Retweets: %d" % t.retweets)
		print("Text: %s" % t.text)
		print("Mentions: %s" % t.mentions)
		print("Hashtags: %s\n" % t.hashtags)

	# Exemplo de coleta de tweets do user 'peticormei' dentro da faixa de datas de 26/06/2017 a 29/06/2017, limitando a 20 tweets
	tweetCriteria = got.manager.TweetCriteria().setUsername("peticormei").setSince("2017-06-26").setUntil("2017-06-29").setMaxTweets(20)
	tweet = got.manager.TweetManager.getTweets(tweetCriteria)
        for tw in tweet:
	        printTweet("### Exemplo - Get tweets by username and bound dates [peticormei, '26/06/2017', '29/06/2017']", tw)

	# Exemplo de coleta de tweets por palavra-chave, dentro de uma faixa de data
	tweetCriteria = got.manager.TweetCriteria().setQuerySearch('spiderman').setSince("2017-01-01").setUntil("2017-06-29").setMaxTweets(100)
	tweet = got.manager.TweetManager.getTweets(tweetCriteria)
        for t in tweet:
	        printTweet("### Exemplo - Get tweets by subject and bound dates [Spiderman, '26/06/2017', '29/06/2017']", t)
if __name__ == '__main__':
	main()
